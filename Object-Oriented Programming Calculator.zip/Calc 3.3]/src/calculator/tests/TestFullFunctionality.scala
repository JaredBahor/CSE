package tests

import calculator.model.Calculator
import jdk.nashorn.internal.codegen.CompilerConstants.Call
import org.scalatest.FunSuite

class TestFullFunctionality extends FunSuite{

  val EPSILON: Double = 0.000001

  def equalDoubles(d1: Double, d2: Double): Boolean = {
    (d1 - d2).abs < EPSILON
  }

  test("Full functionality"){

    val calculator: Calculator = new Calculator()
    calculator.numberPressed(3)
    calculator.multiplyPressed()
    calculator.addPressed()
    calculator.numberPressed(4)
    calculator.equalsPressed()
    assert(equalDoubles(calculator.displayNumber(), 7.0), calculator.displayNumber())


    val calculator1: Calculator = new Calculator()
    calculator1.numberPressed(1)
    calculator1.addPressed()
    calculator1.numberPressed(2)
    calculator1.multiplyPressed()
    calculator1.decimalPressed()
    calculator1.numberPressed(8)
    calculator1.equalsPressed()
    assert(equalDoubles(calculator1.displayNumber(), 2.4), calculator1.displayNumber())


    val calculator2: Calculator = new Calculator()
    calculator2.numberPressed(1)
    calculator2.addPressed()
    calculator2.numberPressed(1)
    calculator2.equalsPressed()
    calculator2.numberPressed(3)
    assert(equalDoubles(calculator2.displayNumber(), 3.0), calculator2.displayNumber())


    val calculator3: Calculator = new Calculator()
    calculator3.numberPressed(1)
    calculator3.addPressed()
    calculator3.numberPressed(1)
    calculator3.clearPressed()
    calculator3.numberPressed(2)
    calculator3.addPressed()
    calculator3.numberPressed(3)
    calculator3.equalsPressed()
    calculator3.addPressed()
    calculator3.numberPressed(4)
    calculator3.equalsPressed()
    assert(equalDoubles(calculator3.displayNumber(), 9.0), calculator3.displayNumber())


    val calculator4: Calculator = new Calculator()
    calculator4.clearPressed()
    calculator4.numberPressed(4)
    calculator4.addPressed()
    calculator4.numberPressed(2)
    calculator4.equalsPressed()
    assert(equalDoubles(calculator4.displayNumber(), 6.0), calculator4.displayNumber())
    calculator4.clearPressed()
    assert(equalDoubles(calculator4.displayNumber(), 0.0), calculator4.displayNumber())


    val calculator5: Calculator = new Calculator()
    calculator5.numberPressed(1)
    calculator5.numberPressed(0)
    calculator5.decimalPressed()
    calculator5.numberPressed(5)
    calculator5.addPressed()
    calculator5.decimalPressed()
    calculator5.numberPressed(5)
    calculator5.multiplyPressed()
    calculator5.numberPressed(3)
    calculator5.equalsPressed()
    assert(equalDoubles(calculator5.displayNumber(), 33.0), calculator5.displayNumber())




  }
}
