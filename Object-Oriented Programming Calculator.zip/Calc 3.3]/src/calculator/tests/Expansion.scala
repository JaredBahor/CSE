package calculator.tests

import calculator.model.Calculator
import org.scalatest.FunSuite

class Expansion extends FunSuite {

  val EPSILON: Double = 0.000001

  def equalDoubles(d1: Double, d2: Double): Boolean = {
    (d1 - d2).abs < EPSILON
  }

  test("Enter Numbers Test 2.0") {
    //Negate Tests//
    val calculator: Calculator = new Calculator()
    calculator.numberPressed(5)
    calculator.numberPressed(9)
    calculator.negate()
    assert(equalDoubles(calculator.displayNumber(), -59.0), calculator.displayNumber())

    val calculator1: Calculator = new Calculator()
    calculator1.numberPressed(4)
    calculator1.negate()
    calculator1.subtractPressed()
    calculator1.numberPressed(4)
    calculator1.equalsPressed()
    assert(equalDoubles(calculator1.displayNumber(), -8.0), calculator1.displayNumber())

    val calculator2: Calculator = new Calculator()
    calculator2.numberPressed(4)
    calculator2.subtractPressed()
    calculator2.numberPressed(4)
    calculator2.negate()
    calculator2.equalsPressed()
    assert(equalDoubles(calculator2.displayNumber(), 8.0), calculator2.displayNumber())

    //Cosine Tests//
    val calculator3: Calculator = new Calculator()
    calculator3.numberPressed(5)
    calculator3.numberPressed(0)
    calculator3.cosine()
    assert(equalDoubles(calculator3.displayNumber(), .9649660284), calculator3.displayNumber())

    val calculator4: Calculator = new Calculator()
    calculator4.numberPressed(9)
    calculator4.numberPressed(0)
    calculator4.cosine()
    assert(equalDoubles(calculator4.displayNumber(), -0.44807361612), calculator4.displayNumber())

    //Sin Tests//
    val calculator5: Calculator = new Calculator()
    calculator5.numberPressed(4)
    calculator5.numberPressed(2)
    calculator5.sin()
    assert(equalDoubles(calculator5.displayNumber(), -0.91652154791), calculator5.displayNumber())

    val calculator6: Calculator = new Calculator()
    calculator6.numberPressed(8)
    calculator6.numberPressed(2)
    calculator6.sin()
    assert(equalDoubles(calculator6.displayNumber(), 0.31322878243), calculator6.displayNumber())

    //To Radians Test//
    val calculator7: Calculator = new Calculator()
    calculator7.numberPressed(9)
    calculator7.numberPressed(0)
    calculator7.toRad()
    assert(equalDoubles(calculator7.displayNumber(), 1.5707963267948), calculator7.displayNumber())

    val calculator8: Calculator = new Calculator()
    calculator8.numberPressed(2)
    calculator8.numberPressed(5)
    calculator8.toRad()
    assert(equalDoubles(calculator8.displayNumber(), 0.436332), calculator8.displayNumber())

    //To Degree Test//
    val calculator9: Calculator = new Calculator()
    calculator9.numberPressed(3)
    calculator9.toDeg()
    assert(equalDoubles(calculator9.displayNumber(), 171.887338539246), calculator9.displayNumber())

    val calculator10: Calculator = new Calculator()
    calculator10.numberPressed(1)
    calculator10.numberPressed(5)
    calculator10.toDeg()
    assert(equalDoubles(calculator10.displayNumber(), 859.43669269623), calculator10.displayNumber())

  }

}
