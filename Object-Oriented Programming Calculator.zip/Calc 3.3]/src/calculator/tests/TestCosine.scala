package calculator.tests

import calculator.model.Calculator
import org.scalatest.FunSuite

class TestCosine extends FunSuite {

  val EPSILON: Double = 0.000001

  def equalDoubles(d1: Double, d2: Double): Boolean = {
    (d1 - d2).abs < EPSILON
  }

  // Example test case
  test("Enter Numbers Test 2.0") {
    val calculator: Calculator = new Calculator()

    calculator.numberPressed(9)
    calculator.numberPressed(0)
    calculator.cosine()

  }

}
