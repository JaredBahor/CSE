package calculator.tests

import org.scalatest.FunSuite
import calculator.model.Calculator

class personalFULL extends FunSuite{

  val EPSILON: Double = 0.000001

  def equalDoubles(d1: Double, d2: Double): Boolean = {
    (d1 - d2).abs < EPSILON
  }

  test("fully works????"){
    val calculator: Calculator = new Calculator()
    calculator.numberPressed(3)
    calculator.addPressed()
    calculator.multiplyPressed()
    calculator.numberPressed(4)
    calculator.equalsPressed()
    assert(calculator.displayNumber() == 12.0)
    assert(equalDoubles(calculator.displayNumber(), 12.0), calculator.displayNumber())


    val calculator1: Calculator = new Calculator()
    calculator1.numberPressed(1)
    calculator1.addPressed()
    calculator1.numberPressed(2)
    calculator1.multiplyPressed()
    calculator1.decimalPressed()
    calculator1.numberPressed(8)
    calculator1.equalsPressed()
    assert(calculator1.displayNumber() == 2.6)
    assert(equalDoubles(calculator1.displayNumber(), 2.6), calculator1.displayNumber())


    val calculator2: Calculator = new Calculator()
    calculator2.numberPressed(1)
    calculator2.addPressed()
    calculator2.numberPressed(1)
    calculator2.equalsPressed()
    calculator2.numberPressed(3)
    assert(equalDoubles(calculator2.displayNumber(), 3.0), calculator2.displayNumber())

    val calculator3: Calculator = new Calculator()
    calculator3.numberPressed(1)
    calculator3.addPressed()
    calculator3.numberPressed(1)
    calculator3.clearPressed()
    calculator3.numberPressed(2)
    calculator3.addPressed()
    calculator3.numberPressed(3)
    calculator3.equalsPressed()
    calculator3.addPressed()
    calculator3.numberPressed(4)
    calculator3.equalsPressed()
    assert(equalDoubles(calculator3.displayNumber(), 10.0), calculator3.displayNumber())

  }
}
