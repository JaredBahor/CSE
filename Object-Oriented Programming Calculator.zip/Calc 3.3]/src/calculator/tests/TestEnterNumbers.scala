package tests

import calculator.model.Calculator
import org.scalatest.FunSuite

class TestEnterNumbers extends FunSuite {

  val EPSILON: Double = 0.000001

  def equalDoubles(d1: Double, d2: Double): Boolean = {
    (d1 - d2).abs < EPSILON
  }

  // Example test case
  test("Enter Numbers Test 2.0") {
    val calculator: Calculator = new Calculator()

    calculator.numberPressed(9)
    calculator.subtractPressed()
    calculator.numberPressed(2)
    calculator.equalsPressed()
    assert(equalDoubles(calculator.displayNumber(), 7.0), calculator.displayNumber())


    val calculator1: Calculator = new Calculator()
    calculator1.numberPressed(1)
    calculator1.numberPressed(2)
    calculator1.numberPressed(5)
    assert(equalDoubles(calculator1.displayNumber(), 125.0), calculator1.displayNumber())


    val calculator2: Calculator = new Calculator()
    calculator2.numberPressed(4)
    calculator2.numberPressed(1)
    calculator2.numberPressed(7)
    assert(equalDoubles(calculator2.displayNumber(), 417.0), calculator2.displayNumber())


    val calculator3: Calculator = new Calculator()
    calculator3.numberPressed(0)
    calculator3.numberPressed(0)
    calculator3.numberPressed(0)
    calculator3.numberPressed(0)
    calculator3.numberPressed(2)
    calculator3.decimalPressed()
    calculator3.numberPressed(3)
    assert(equalDoubles(calculator3.displayNumber(), 2.3), calculator3.displayNumber())


    val calculator4: Calculator = new Calculator()
    calculator4.numberPressed(2)
    calculator4.decimalPressed()
    calculator4.decimalPressed()
    calculator4.numberPressed(3)
    calculator4.decimalPressed()
    calculator4.numberPressed(5)
    assert(equalDoubles(calculator4.displayNumber(), 2.35), calculator4.displayNumber())


    val calculator5: Calculator = new Calculator()
    calculator5.decimalPressed()
    calculator5.numberPressed(0)
    calculator5.numberPressed(0)
    calculator5.numberPressed(0)
    calculator5.decimalPressed()
    calculator5.numberPressed(5)
    assert(equalDoubles(calculator5.displayNumber(), .0005), calculator5.displayNumber())


    val calculator6: Calculator = new Calculator()
    calculator6.numberPressed(5)
    calculator6.numberPressed(95)
    calculator6.numberPressed(6)
    assert(equalDoubles(calculator6.displayNumber(), 5956), calculator6.displayNumber())


    val calculator7: Calculator = new Calculator()
    calculator7.clearPressed()
    calculator7.numberPressed(8)
    calculator7.numberPressed(9)
    assert(equalDoubles(calculator7.displayNumber(), 89), calculator7.displayNumber())
  }
}
