package tests

import org.scalatest.FunSuite
import calculator.model._

class TestFourFunctions extends FunSuite{

  val EPSILON: Double = 0.000001

  def equalDoubles(d1: Double, d2: Double): Boolean = {
    (d1 - d2).abs < EPSILON
  }

  test("4 function"){
    val calculator: Calculator = new Calculator()
    calculator.numberPressed(5)
    calculator.multiplyPressed()
    calculator.numberPressed(4)
    calculator.equalsPressed()
    assert(equalDoubles(calculator.displayNumber(), 20.0), calculator.displayNumber())


    val calculator1: Calculator = new Calculator()
    calculator1.numberPressed(3)
    calculator1.addPressed()
    calculator1.numberPressed(4)
    calculator1.decimalPressed()
    calculator1.numberPressed(3)
    calculator1.equalsPressed()
    assert(equalDoubles(calculator1.displayNumber(), 7.3), calculator1.displayNumber())


    val calculator2: Calculator = new Calculator()
    calculator2.numberPressed(10)
    calculator2.dividePressed()
    calculator2.numberPressed(2)
    calculator2.equalsPressed()
    assert(equalDoubles(calculator2.displayNumber(), 5), calculator2.displayNumber())


    val calculator3: Calculator = new Calculator()
    calculator3.numberPressed(10)
    calculator3.subtractPressed()
    calculator3.numberPressed(2)
    calculator3.equalsPressed()
    assert(equalDoubles(calculator3.displayNumber(), 8), calculator3.displayNumber())


    val calculator4: Calculator = new Calculator()
    calculator4.numberPressed(10)
    calculator4.dividePressed()
    calculator4.multiplyPressed()
    calculator4.addPressed()
    calculator4.numberPressed(2)
    calculator4.equalsPressed()
    assert(equalDoubles(calculator4.displayNumber(), 12), calculator4.displayNumber())


    val calculator5: Calculator = new Calculator()
    calculator5.numberPressed(10)
    calculator5.decimalPressed()
    calculator5.numberPressed(2)
    calculator5.addPressed()
    calculator5.decimalPressed()
    calculator5.numberPressed(8)
    calculator5.equalsPressed()
    assert(equalDoubles(calculator5.displayNumber(), 11), calculator5.displayNumber())


    val calculator6: Calculator = new Calculator()
    calculator6.numberPressed(3)
    calculator6.decimalPressed()
    calculator6.dividePressed()
    calculator6.numberPressed(4)
    calculator6.decimalPressed()
    calculator6.numberPressed(3)
    calculator6.decimalPressed()
    calculator6.equalsPressed()
    assert(equalDoubles(calculator6.displayNumber(), 0.6976744186046512), calculator6.displayNumber())

  }
}
