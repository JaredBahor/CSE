package calculator.model


class LHS(calculator: Calculator) extends State(calculator) {


  override def displayNumber(): Double = {
    calculator.LHSnumber
  }

  override def clearPressed(): Unit = {
    calculator.LHSnumber = 0.0
    calculator.RHSnumber = 0.0
    calculator.CurrentString = ""
    calculator.op = ""
    calculator.CurrentNumber = 0.0
  }

  override def numberPressed(number: Int): Unit = {
    calculator.CurrentString += number.toString
    calculator.LHSnumber = calculator.CurrentString.toDouble
  }

  override def dividePressed(): Unit = {
    calculator.CurrentString = ""
    calculator.op = "/"
    calculator.state = new RHS(calculator)
  }

  override def multiplyPressed(): Unit = {
    calculator.CurrentString = ""
    calculator.op = "*"
    calculator.state = new RHS(calculator)
  }

  override def subtractPressed(): Unit = {
    calculator.CurrentString = ""
    calculator.op = "-"
    calculator.state = new RHS(calculator)
  }

  override def addPressed(): Unit = {
    calculator.CurrentString = ""
    calculator.op = "+"
    calculator.state = new RHS(calculator)
  }

  override def equalsPressed(): Unit = {
    calculator.displayNumber()
  }

  override def decimalPressed(): Unit = {
    calculator.CurrentString += "."
    calculator.state = new DecimalpressedLHS(calculator)
  }

  override def negate(): Unit = {
    val num = calculator.LHSnumber * -1
    calculator.LHSnumber = num
  }

  override def cosine(): Unit = {
    calculator.CurrentNumber = calculator.LHSnumber
    val cos = math.cos(calculator.CurrentNumber)
    calculator.LHSnumber = cos.toDouble
  }

  override def sin(): Unit = {
    calculator.CurrentNumber = calculator.LHSnumber
    val sin = math.sin(calculator.CurrentNumber)
    calculator.LHSnumber = sin
  }

  override def toRad(): Unit = {
    calculator.CurrentNumber = calculator.LHSnumber
    val radian = math.toRadians(calculator.CurrentNumber)
    calculator.LHSnumber = radian
  }

  override def toDeg(): Unit = {
    calculator.CurrentNumber = calculator.LHSnumber
    val degree = math.toDegrees(calculator.CurrentNumber)
    calculator.LHSnumber = degree
  }

  override def PI(): Unit = {
    calculator.CurrentNumber = scala.math.Pi
    calculator.LHSnumber = calculator.CurrentNumber
  }
}
