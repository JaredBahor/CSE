package calculator.model

import scala.math

class Decimalpressed(calculator: Calculator) extends State(calculator) {


  override def displayNumber(): Double = {
    calculator.RHSnumber
  }

  override def clearPressed(): Unit = {
    calculator.state = new LHS(calculator)
    calculator.CurrentNumber = 0.0
  }

  override def numberPressed(number: Int): Unit = {
    calculator.CurrentString += number.toString
    calculator.RHSnumber = calculator.CurrentString.toDouble
  }

  override def dividePressed(): Unit = {
    calculator.op = "/"
    calculator.state = new LHS(calculator)
  }

  override def multiplyPressed(): Unit = {
    calculator.op = "*"
    calculator.state = new LHS(calculator)
  }

  override def subtractPressed(): Unit = {
    calculator.op = "-"
    calculator.state = new LHS(calculator)
  }

  override def addPressed(): Unit = {
    calculator.op = "+"
    calculator.state = new LHS(calculator)
  }

  override def equalsPressed(): Unit = {
    calculator.CurrentString = ""
    val operation = calculator.operatorTable(calculator.op)
    calculator.LHSnumber = operation(calculator.LHSnumber, calculator.RHSnumber)
    calculator.state = new LHS(calculator)
  }

  override def decimalPressed(): Unit = {
    //no functionality when already pressed
  }

  override def negate(): Unit = {
    val num = calculator.RHSnumber * -1
    calculator.RHSnumber = num
  }

  override def cosine(): Unit = {
    calculator.CurrentNumber = calculator.RHSnumber
    val cos = math.cos(calculator.CurrentNumber)
    calculator.RHSnumber = cos
  }

  override def sin(): Unit = {
    calculator.CurrentNumber = calculator.RHSnumber
    val sin = math.sin(calculator.CurrentNumber)
    calculator.RHSnumber = sin
  }

  override def toRad(): Unit = {
    calculator.CurrentNumber = calculator.RHSnumber
    val radian = math.toRadians(calculator.CurrentNumber)
    calculator.RHSnumber = radian
  }

  override def toDeg(): Unit = {
    calculator.CurrentNumber = calculator.RHSnumber
    val degree = math.toDegrees(calculator.CurrentNumber)
    calculator.RHSnumber = degree
  }

  override def PI(): Unit = {
    calculator.CurrentNumber = scala.math.Pi
    calculator.RHSnumber = calculator.CurrentNumber
  }
}
