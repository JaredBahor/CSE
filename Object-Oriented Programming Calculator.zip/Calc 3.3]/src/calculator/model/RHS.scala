package calculator.model

class RHS(calculator: Calculator) extends State(calculator) {


  override def displayNumber(): Double = {
    calculator.RHSnumber
  }

  override def clearPressed(): Unit = {
    calculator.CurrentNumber = 0.0
    calculator.LHSnumber = 0.0
    calculator.RHSnumber = 0.0
    calculator.CurrentString = ""
    calculator.op = ""
    calculator.state = new LHS(calculator)
  }

  override def numberPressed(number: Int): Unit = {
    calculator.CurrentString += number.toString
    calculator.RHSnumber = calculator.CurrentString.toDouble
    calculator.state = new RHSoperator(calculator)
  }

  override def dividePressed(): Unit = {
    calculator.op = "/"
  }

  override def multiplyPressed(): Unit = {
    calculator.op = "*"
  }

  override def subtractPressed(): Unit = {
    calculator.op = "-"
  }

  override def addPressed(): Unit = {
    calculator.op = "+"
  }

  override def equalsPressed(): Unit = {
    calculator.CurrentString = ""
    val operation = calculator.operatorTable(calculator.op)
    calculator.CurrentString = operation(calculator.LHSnumber, calculator.RHSnumber).toString
    val num = operation(calculator.LHSnumber, calculator.RHSnumber)
    calculator.LHSnumber = num
    calculator.RHSnumber = 0.0
    calculator.state = new LHS(calculator)
  }

  override def decimalPressed(): Unit = {
    calculator.CurrentString += "."
    calculator.state = new DecimalpressedRHSop(calculator)
  }

  override def negate(): Unit = {
    val num = calculator.RHSnumber * -1
    calculator.RHSnumber = num
  }

  override def cosine(): Unit = {
    calculator.CurrentNumber = calculator.RHSnumber
    val cos = math.cos(calculator.CurrentNumber)
    calculator.RHSnumber = cos
  }

  override def sin(): Unit = {
    calculator.CurrentNumber = calculator.RHSnumber
    val sin = math.sin(calculator.CurrentNumber)
    calculator.RHSnumber = sin
  }

  override def toRad(): Unit = {
    calculator.CurrentNumber = calculator.RHSnumber
    val radian = math.toRadians(calculator.CurrentNumber)
    calculator.RHSnumber = radian
  }

  override def toDeg(): Unit = {
    calculator.CurrentNumber = calculator.RHSnumber
    val degree = math.toDegrees(calculator.CurrentNumber)
    calculator.RHSnumber = degree
  }

  override def PI(): Unit = {
    calculator.CurrentNumber = scala.math.Pi
    calculator.RHSnumber = calculator.CurrentNumber
  }
}


