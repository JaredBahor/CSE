package calculator.model

abstract class State(val calculator: Calculator) {

  def displayNumber(): Double

  def clearPressed(): Unit

  def numberPressed(number: Int): Unit

  def dividePressed(): Unit

  def multiplyPressed(): Unit

  def subtractPressed(): Unit

  def addPressed(): Unit

  def equalsPressed(): Unit

  def decimalPressed(): Unit

  def negate(): Unit

  def cosine(): Unit

  def sin(): Unit

  def toDeg(): Unit

  def toRad(): Unit

  def PI(): Unit

}
