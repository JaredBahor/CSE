package calculator.model


class Calculator() {

  var CurrentNumber: Double = 0.0// shows current number used for cosine and sin

  var LHSnumber: Double = 0.0// number from LHS
  var RHSnumber: Double = 0.0// number from RHS
  var CurrentString: String = ""

  val pow = (a: Double, b: Double) => Math.pow(a, b)
  val mul = (a: Double, b: Double) => a * b
  val div = (a: Double, b: Double) => a / b
  val add = (a: Double, b: Double) => a + b
  val sub = (a: Double, b: Double) => a - b
  val operatorTable: Map[String, (Double, Double) => Double] = Map(
    "^" -> pow,
    "*" -> mul,
    "/" -> div,
    "+" -> add,
    "-" -> sub
  )
  var op: String = ""// represents the operator to use in the call



  var state: State = new LHS(this)

  def displayNumber(): Double = {
    this.state.displayNumber()
  }

  def clearPressed(): Unit = {
    this.state.clearPressed()
  }

  def numberPressed(number: Int): Unit = {
    this.state.numberPressed(number)
    CurrentNumber = number.toDouble
  }

  def dividePressed(): Unit = {
    this.state.dividePressed()
  }

  def multiplyPressed(): Unit = {
    this.state.multiplyPressed()
  }

  def subtractPressed(): Unit = {
    this.state.subtractPressed()
  }

  def addPressed(): Unit = {
    this.state.addPressed()
  }

  def equalsPressed(): Unit = {
    this.state.equalsPressed()
  }

  def decimalPressed(): Unit = {
    this.state.decimalPressed()
  }

  def negate(): Unit = {
    this.state.negate()
  }

  def cosine(): Unit = {
    this.state.cosine()
  }

  def sin(): Unit = {
    this.state.sin()
  }

  def toRad(): Unit = {
    this.state.toRad()
  }

  def toDeg(): Unit = {
    this.state.toDeg()
  }

  def PI(): Unit = {
    this.state.PI()
  }
}
