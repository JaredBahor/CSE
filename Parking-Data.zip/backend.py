
def get_matches(data, key, value):
  newLst = []
  for i in data:
    if key in i:
      if i.get(key) == value:
        newLst.append(i)
  return newLst

def list_descriptions(data):
  newlst = []
  for i in data: 
   if 'tow_description' in i:
     if i.get('tow_description') not in newlst:
       newlst.append(i.get('tow_description'))
  return newlst

def count_by_month(data):
  newlst = [0,0,0,0,0,0,0,0,0,0,0,0]
  for i in data:
    value = i['tow_date']
    month = int(value[5] + value[6])
    newlst[month-1]+=1
  return newlst 
    
def count_by_day(data):
  newlst = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
  for i in data:
    value = i['tow_date']
    day = int(value[8] + value[9])
    newlst[day-1]+=1
  return newlst