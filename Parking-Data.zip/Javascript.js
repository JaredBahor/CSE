function getData(){
  ajaxGetRequest("/ScatterJSON", scatter);
  ajaxGetRequest("/PiechartJSON", pie);
  ajaxGetRequest("/LinegraphJSON", line);
}
getData();


function scatter (scatter){
  let ex = JSON.parse(scatter);
  let graph = {
  x: [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31],
  y: ex,
  name: 'tows',
  mode: 'markers',
  type: 'scatter'
  };
  let layout = {
    title: {
      text: 'Tows by Day of the Month',
    },
    xaxis: {
      title:  {
        text: 'Day of the Month',
      }
    },
    yaxis: {
      title:  {
        text: '# of tows',
      }
  
    }
    }
  Plotly.newPlot('scatterPlot', [graph], layout);
}


function pie (pie){
  ex = JSON.parse(pie)
  let graph = [{
    values: ex,
    labels: ["District A", "District B", "District C", "District D", "District E"],
    type: 'pie'
  }];
  let layout = {
    title: 'Tows by District',
  };

  Plotly.newPlot('pieChart', graph, layout);
}

function line (line){
  ex = JSON.parse(line)
  let IllegalVehicle = {
    x: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    y: ex[0],
    name: 'Illegal Vehicle',
    type: 'lines'
  };
  let Accident = {
    x: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    y: ex[1],
    name: 'Accident',
    type: 'lines'
  };
  let AbandonedVehicle = {
    x: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    y: ex[2],
    name: 'Abandoned Vehicle',
    type: 'lines'
  };
  let StolenVehicle = {
    x: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    y: ex[3],
    name: 'Stolen Vehicle',
    type: 'lines'
  };
  let IllegallyParked = {
    x: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    y: ex[4],
    name: 'Illegally Parked',
    type: 'lines'
  };
  let Impounded = {
    x: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    y: ex[5],
    name: 'Impounded',
    type: 'lines'
  };
  let GoneOnArrival = {
    x: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    y: ex[6],
    name: 'Gone On Arrival',
    type: 'lines'
  };
  let data = [IllegalVehicle, Accident, AbandonedVehicle, StolenVehicle, IllegallyParked, Impounded, GoneOnArrival];
  let layout = {
    title: '# of Tows by Month and Description',
    xaxis: {
      title:  'Month'
    },
    yaxis: {
      title: '# of Tows'
      }
  };
  Plotly.newPlot("lineGraph", data, layout);
}


// path -- string specifying URL to which data request is sent 
// callback -- function called by JavaScript when response is received                       
function ajaxGetRequest(path, callback) {
    let request = new XMLHttpRequest();
    request.onreadystatechange = function() {
          if (this.readyState===4 && this.status ===200) {
              callback(this.response);
            }
    }
    request.open("GET", path);
    request.send();
}

