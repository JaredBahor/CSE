import bottle 
import json
import cache
import backend


@bottle.route("/")
def staticHTML():
  return bottle.static_file("index.html",root= "")


@bottle.route("/Javascript.js")
def staticJavaScript():
  return bottle.static_file("Javascript.js",root= "")


@bottle.route("/ScatterJSON")
# # of tows on each day of every month
def scatter():
  data = cache.read_cache('cached_data.csv')
  daylst = backend.count_by_day(data)
  return json.dumps(daylst)


@bottle.route("/PiechartJSON")
#Police districts responsible for tows 
def pie():
  data = cache.read_cache('cached_data.csv')
  dictlst = cache.minimize_dictionaries(data,['police_district'])
  labels = ["District A", "District B", "District C", "District D", "District E"]
  values = [0,0,0,0,0]
  for key in dictlst:
    if key['police_district'] == "District A":
      values[0] += 1
    if key['police_district'] == "District B":
      values[1] += 1
    if key['police_district'] == "District C":
      values[2] += 1
    if key['police_district'] == "District D":
      values[3] += 1
    if key['police_district'] == "District E":
      values[4] += 1
  return json.dumps(values)

@bottle.route("/LinegraphJSON")
# why cars were towed month to month
def line():
  data = cache.read_cache('cached_data.csv')
  dictlst = cache.minimize_dictionaries(data,['tow_date','tow_description'])
  keys = ['ILLEGAL VEHICLE', 'ACCIDENT', 'ABANDONED VEHICLE', 'STOLEN VEHICLE', 'ILLEGALLY PARKED','IMPOUNDED', 'GONE ON ARRIVAL']
  lst1 = []
  months = backend.count_by_month(data)
  for i in keys:
    x = backend.get_matches(data, "tow_description", i)
    months = backend.count_by_month(x)
    lst1.append(months)
  return json.dumps(lst1)


import os.path
import cache # This assumes that your functions from parts 2 & 3 are in a file named cache.py
def load_data( ):
   csv_file = 'cached_data.csv'
   if not os.path.isfile(csv_file):
       query_str = "?$limit=10000"
       url = "https://data.buffalony.gov/resource/5c88-nfii.json" + query_str
       data = cache.get_data(url)
       data = cache.minimize_dictionaries(data, ['tow_date', 'tow_description', 'police_district'])
       cache.write_cache(data, csv_file)

load_data()

bottle.run(host="0.0.0.0", port=8080, debug=True)
