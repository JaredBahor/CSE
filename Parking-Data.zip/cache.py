import csv 
import json

def read_csv_header(reader):
  for row in reader:
    return row

def read_data(reader,keylist):
  dictlist = []
  for row in reader:
    dict1 = {}
    for num in range(0,len(keylist)):
      dict1[keylist[num]] = row[num].rstrip()
    dictlist.append(dict1)
  return dictlist
  
def write_csv_header(writer,keydict):
  keylist = []
  for key in keydict:
    keylist.append(key)
  writer.writerow(keylist)
  return keylist

def write_dictionaries_to_csv(writer,dictlist,keylist):
  for kv in dictlist:
    list1 = []
    for key in keylist:
      list1.append(kv[key])
    writer.writerow(list1)
  return 


import urllib.request
def get_data(strurl):
  url = strurl
  response = urllib.request.urlopen(url)
  content = response.read().decode()
  data = json.loads(content)
  return data

def minimize_dictionaries(dictlst,strlist):
  lst = []
  for i in dictlst:
    dict1 = {}
    for key in strlist:
      dict1[key] = i.get(key,"District A")
    lst.append(dict1)
  return lst

def write_dictionaries_to_csv(writer,dictlist,keylist):
  for kv in dictlist:
    list1 = []
    for key in keylist:
      list1.append(kv[key])
    writer.writerow(list1)
  return 

def write_cache(dictlst,strfile):
  with open(strfile, "w") as f:
    writer = csv.writer(f)
    lst = list(dictlst[0].keys())
    writer.writerow(lst)
    write_dictionaries_to_csv(writer,dictlst,lst)
  return 

def read_data(reader,keylist):
  dictlist = []
  for row in reader:
    dict1 = {}
    for num in range(0,len(keylist)):
      dict1[keylist[num]] = row[num].rstrip()
    dictlist.append(dict1)
  return dictlist
  
def read_csv_header(reader):
  for row in reader:
    return row

def read_cache(strfile):
  with open(strfile) as f:
    reader = csv.reader(f)
    row = read_csv_header(reader)
    return read_data(reader,row)





