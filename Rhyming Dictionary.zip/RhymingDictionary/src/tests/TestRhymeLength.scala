package tests

import org.scalatest._
import rhymes.RhymingDictionary

class TestRhymeLength extends FunSuite {

  test("Rhyme Length"){
    val dictionaryFilename: String = "data/cmudict-0.7b"
    val rhymingDictionary = new RhymingDictionary(dictionaryFilename)

    val speedboat1 = "speedboat"//S P IY1 D B OW2 T
    val uncoat1 = "uncoat"// 1 //     AH0 N K OW1 T

    val baited1 = "baited"//                      B EY1 T IH0 D
    val annotated1 = "annotated"// 2 // AE2 N AH0 T EY1 T IH0 D

    val vegas1 = "vegas" //               V EY1 G AH0 S
    val bodegas1 = "bodegas"// 2 // B OW0 D EY1 G AH0 S

    val thundering1 = "thundering"//   TH AH1 N D ER0 IH0 NG
    val wondering1 = "wondering"// 3 // W AH1 N D ER0 IH0 NG

    val reverie1 = "reverie"//                   R EH1 V ER0 IY0
    val computing1 = "computing"// 0 // K AH0 M P Y UW1 T IH0 NG

    val computervision1 = "computervision"// K AH0 M P Y UW1 T ER0 V IH2 ZH AH0 N
    val computervision2 = "computervision"//5

    val madeupword1 = "jrneeejrnce"//DNE
    val madeupword2 = "eurneurcnekjrc"// 0 //

    val zwick1 = "zwick"
    val bison1 = "bison"

    assert(rhymingDictionary.rhymeLength(uncoat1, speedboat1) == 1)
    assert(rhymingDictionary.rhymeLength(annotated1, baited1) == 2)
    assert(rhymingDictionary.rhymeLength(bodegas1, vegas1) == 2)
    assert(rhymingDictionary.rhymeLength(wondering1, thundering1) == 3)
    assert(rhymingDictionary.rhymeLength(reverie1, computing1) == 0)
    assert(rhymingDictionary.rhymeLength(computervision1, computervision2) == 5)
    assert(rhymingDictionary.rhymeLength(madeupword1, madeupword2) == 0)
    assert(rhymingDictionary.rhymeLength(zwick1,bison1) == 0)
  }
}


