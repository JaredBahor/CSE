package tests

import org.scalatest._
import rhymes.RhymingDictionary

class TestIsRhyme extends FunSuite {


  test("check if two words rhyme using the isRhyme method") {
    val dictionaryFilename: String = "data/cmudict-0.7b"
    val rhymingDictionary = new RhymingDictionary(dictionaryFilename)


    val cuter1 = "cuter" //                               // K Y UW1 T ER0
    val computer1 = "computer"// yes they rhyme //   K AH0 M P Y UW1 T ER0

    val riverbank1 = "riverbank"   //R IH1 V ER0 B AE2 NG K
    val ronk1 = "ronk"// NO they do not rhyme // R AA1 NG K

    val scared1 = "scared"
    val shorthaired1 = "shorthaired"// yes they rhyme

    val remote1 = "remote"//                   //R IH0 M OW1 T
    val rewrote1 = "rewrote"// yes they rhyme // R IY0 R OW1 T

    val ambergris1 = "ambergris"//AE1 M B ER0 G R IH0 S
    val amis1 = "amis"// yes they rhyme//   AE1 M IH0 S

    val stocker1 = "stocker"
    val stockholder1 = "stockholder"// yes they rhyme

    val gutwaks1 = "gutwaks"//                    //G AH1 T W AA2 K S
    val renfred1 = "renfred"// No they do not rhyme// R EH1 N F ER0 D

    val corso1 = "CORSO"
    val luber1 = "LUBER"// No they do not rhyme

    val computervision1 = "computervision"// K AH0 M P Y UW1 T ER0 V IH2 ZH AH0 N
    val computervision2 = "computervision"// yes they rhyme

    val madeupword1 = "jrneeejrnce"//DNE
    val madeupword2 = "eurneurcnekjrc"//

    val ammann1 = "ammann" //AE1 M AH0 N
    val ammeen1 = "ammeen" //AH0 M IY1 N

    val speedboat1 = "speedboat"//          //S P IY1 D B OW2 T
    val uncoat1 = "uncoat"// Yes they rhyme//     AH0 N K OW1 T

    val schmidlin1 = "schmidlin" // SH M IH1 D L IH0 N
    val wondering1 = "wondering"


    assert(rhymingDictionary.isRhyme(computer1, cuter1) == true)
    assert(rhymingDictionary.isRhyme(ronk1, riverbank1) == false)
    assert(rhymingDictionary.isRhyme(shorthaired1, scared1) == true)
    assert(rhymingDictionary.isRhyme(rewrote1, remote1) == true)
    assert(rhymingDictionary.isRhyme(ambergris1, amis1) == true)
    assert(rhymingDictionary.isRhyme(stocker1, stockholder1) == true)
    assert(rhymingDictionary.isRhyme(gutwaks1, renfred1) == false)
    assert(rhymingDictionary.isRhyme(corso1,luber1) == false)
    assert(rhymingDictionary.isRhyme(computervision1,computervision2) == true)
    assert(rhymingDictionary.isRhyme(madeupword1,madeupword2) == false)
    assert(rhymingDictionary.isRhyme(ammann1,ammeen1) == false)
    assert(rhymingDictionary.isRhyme(speedboat1,uncoat1) == true)
    assert(rhymingDictionary.isRhyme(schmidlin1,wondering1) == false)
  }

}
