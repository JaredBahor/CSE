package tests

import org.scalatest._
import rhymes.RhymingDictionary

class TestAllRhymes extends FunSuite {

  test("all rhymes for a word"){
    val dictionaryFilename: String = "data/cmudict-0.7b"
    val rhymingDictionary = new RhymingDictionary(dictionaryFilename)

    val clogged1 = "clogged"
    val wondering1 = "wondering"
    // always empty
    assert(rhymingDictionary.allRhymes(clogged1) != List())
    //includes input
    val x = rhymingDictionary.allRhymes(wondering1)
    x.contains("WONDERING")
    assert(x.contains("WONDERING") == false)
    assert(rhymingDictionary.allRhymes("srknfowekkmvelrnv") == List())


    assert(rhymingDictionary.allRhymes("wurl").sorted == List("WHIRL", "WHORL", "EARLL", "KERL", "NERL", "ERL", "WERLE", "SPERLE", "BERLE", "SEARL", "SWIRL", "TWIRL", "HURL", "SPERL", "GIRL", "PERL", "CURL", "HEIMERL", "PERLE", "BURL", "MERLE", "EARLE", "SEARLE", "SHIRL", "EBERL", "UNFURL", "PEARLE", "HERL", "PEARL", "EARL", "SCHOOLGIRL", "MERL", "HABERL", "HEARL", "SHOWGIRL", "COWGIRL", "BIRLE").sorted)

      // lab tests

    assert(rhymingDictionary.allRhymes(clogged1).sorted == List("DOGGED", "LOGGED", "METAGOGUED", "LEAPFROGGED", "CATALOGUED", "CATALOGED").sorted)
    assert(rhymingDictionary.allRhymes("with").sorted == List("EDITHE").sorted)
    assert(rhymingDictionary.allRhymes("saurer").sorted == List("SPORRER", "SCHAIRER", "SHIRER", "FORRER", "BORROR", "RORRER", "SCHEIRER").sorted)



  }
}

