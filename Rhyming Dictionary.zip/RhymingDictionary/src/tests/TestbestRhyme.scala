package tests

import org.scalatest.FunSuite
import rhymes.RhymingDictionary

class TestbestRhyme extends FunSuite{

  test("best rhymes"){
    val dictionaryFilename: String = "data/cmudict-0.7b"
    val rhymingDictionary = new RhymingDictionary(dictionaryFilename)

    assert(rhymingDictionary.bestRhyme("clogged") == "DOGGED")
    assert(rhymingDictionary.bestRhyme("a") == "VAYDA")
    assert(rhymingDictionary.bestRhyme("with") == "EDITHE")
    assert(rhymingDictionary.bestRhyme("uncoat") == "TUGBOAT")
    assert(rhymingDictionary.bestRhyme("crack") == "SHERAK")
    assert(rhymingDictionary.bestRhyme("beta") == "VAYDA")
    assert(rhymingDictionary.bestRhyme("alpha") == "FARANDA")
    assert(rhymingDictionary.bestRhyme("clogged") != "CLOGGED")
    assert(rhymingDictionary.bestRhyme("jrve") == "")

  }
}
