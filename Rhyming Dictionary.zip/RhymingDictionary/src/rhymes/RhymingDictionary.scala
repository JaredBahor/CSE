package rhymes

import scala.collection.mutable.ListBuffer
import scala.io.{BufferedSource, Source}

class RhymingDictionary(dictionaryFilename: String) {

  var Bool: Boolean = false
  var counter: Int = 0
  var counter2: Int = -1
  var revcounter: Int = -1
  var sound1st: String = ""
  var sound2nd: String = ""
  var lastsound: String = ""

  //best rhyme global variables
  var alldict: Map[String, Array[String]] = Map()

  def parsefile(word1: String, word2: String): Map[String, Array[String]] = {
    val uppercase1 = (word1.charAt(0))
    val uppercase2 = (word2.charAt(0))
    var Word1upper = word1
    var Word2upper = word2
    if (uppercase1.isLower) {
      Word1upper = word1.toUpperCase()
    }
    if (uppercase2.isLower) {
      Word2upper = word2.toUpperCase()
    }
    var dict: Map[String, Array[String]] = Map().withDefaultValue(Array("DNE"))
    val filename = "data/cmudict-0.7b"
    val file: BufferedSource = Source.fromFile(filename)
    for (line <- file.getLines()) {
      if (line(0) != ';') {
        if (line.contains(Word1upper)) {
          var key1 = line.split("  ")(0)
          var value1 = line.split(" ")
          dict += (key1 -> value1)
        }
        if (line.contains(Word2upper)) {
          var key2 = line.split("  ")(0)
          var value2 = line.split(" ")
          dict += (key2 -> value2)
        }
      }
    }
    return dict
  }

def processStrings(string1sound: Array[String], string2sound: Array[String]): Boolean = {
  val reversed1 = string1sound.reverse
  val reversed2 = string2sound.reverse
  var inc: Int = 0
  for (s1 <- reversed1) {
    var s2 = reversed2(inc)
    inc += 1
    if (s1.length == s2.length){
      if (s1(0) == s2(0)) {
        if (s1.length == 3) {
          if (s1(0) == s2(0)) {
            if (s1(1) == s2(1)) {
              return true
            }
            else{
              return false
            }
          }
          else{
            return false
          }
        }
        if (s2.length == 3) {
          if (s1(0) == s2(0)) {
            if (s1(1) == s2(1)) {
              return true
            }
            else{
              return false
            }
          }
          else {
            return false
          }
        }
      }
      else { // s1(0) == s2(0)
        return false
      }
    }else{
      return false
    }
  }
  return false
}

  def isRhyme(string1: String, string2: String): Boolean = {
    val Upper1 = string1.toUpperCase()
    val Upper2 = string2.toUpperCase()
    var dict1 = parsefile(Upper1, Upper2)
    var string1sound = dict1(Upper1)
    var string2sound = dict1(Upper2)
    val string1exist = dict1.getOrElse(Upper1, "DNE")
    val string2exist = dict1.getOrElse(Upper2, "DNE")
    if (string1exist != "DNE"){
      if (string2exist != "DNE"){
        if (string1sound.length < string2sound.length) { //finds sound length
          val x = processStrings(string1sound, string2sound)
          return x
        }
        else {
          val x = processStrings(string2sound, string1sound)
          return x
        }
      }
      else{
        return false
      }
    }
    else{
      return false
    }
  }

def rhymeLengthhelper(string1sound: Array[String], string2sound: Array[String]): Int = {
  var counter1: Int = 0
  var RhymeLength: Int = 0
  val reversed1 = string1sound.reverse
  val reversed2 = string2sound.reverse
  for (s1 <- reversed1) {
    var s2 = reversed2(counter1)
    counter1 += 1
    if (s1.length == 3) {
      if (s2.length == 3) {
        if (s1(0) == s2(0)) {
          if (s1(1) == s2(1)) {
            RhymeLength += 1
          }
        }
      }
    }
  }
  RhymeLength
}

  def rhymeLength(word1: String,word2: String): Int = {
    val Upper1 = word1.toUpperCase()
    val Upper2 = word2.toUpperCase()
    val dict = parsefile(Upper1, Upper2)
    var string1sound = dict(Upper1)
    var string2sound = dict(Upper2)
    val Rhyme = isRhyme(word1,word2)
    if (Rhyme == true){
      if (string1sound.length < string2sound.length){
        rhymeLengthhelper(string1sound, string2sound)
      }else{
        rhymeLengthhelper(string2sound, string1sound)
      }
    }else{
      return 0
    }
  }

  def parsefileallrhymes(word1: String): Map[String, Array[String]] = {
    val uppercase1 = (word1.charAt(0))
    var Word1upper = word1
    if (uppercase1.isLower) {
      Word1upper = word1.toUpperCase()
    }
    var dict: Map[String, Array[String]] = Map().withDefaultValue(Array("DNE"))
    val filename = "data/cmudict-0.7b"
    val file: BufferedSource = Source.fromFile(filename)
    for (line <- file.getLines()) {
      if (line(0) != ';') {
        if (line != "") {
          var key1 = line.split("  ")(0)
          var value1 = line.split(" ")
          dict += (key1 -> value1)
        }
      }
    }
    return dict
  }

  def processrhymes(string1sound: Array[String], string2sound: Array[String]): Boolean = {
    var inc: Int = 0
    val reversed1 = string1sound.reverse
    val reversed2 = string2sound.reverse
    for (s1 <- reversed1) {
      var s2 = reversed2(inc)
      inc += 1
      if (s1.length == s2.length){
        if (s1(0) == s2(0)) {
          if (s1.length == 3) {
            if (s1(0) == s2(0)) {
              if (s1(1) == s2(1)) {
                return true
              }
              else{
                return false
              }
            }
            else{
              return false
            }
          }
          if (s2.length == 3) {
            if (s1(0) == s2(0)) {
              if (s1(1) == s2(1)) {
                return true
              }
              else{
                return false
              }
            }
            else {
              return false
            }
          }
        }
        else {
          return false
        }
      }else{
        return false
      }
    }
    return false
  }

  def allRhymes(word1: String): List[String] = {
    val Upper1 = word1.toUpperCase()
    val dict1 = parsefileallrhymes(Upper1)
    val word1sound = dict1(Upper1)
    val AllRhyme: ListBuffer[String] = ListBuffer()
    for (rhyme <- dict1.keys){
      val word2sound = dict1(rhyme)
      if (word2sound.length < word1sound.length){
        val result = processrhymes(word2sound, word1sound)
        if (result == true){
          AllRhyme += rhyme
        }
      }else{
        val result = processrhymes(word1sound, word2sound)
        if (result == true){
          AllRhyme += rhyme
        }
      }
    }
    AllRhyme -= Upper1
    val newlist = AllRhyme.toList
    println(newlist)
    newlist
  }

  def wordexist(word1: String): Map[String, Array[String]] = {
    val uppercase1 = (word1.charAt(0))
    var Word1upper = word1
    if (uppercase1.isLower) {
      Word1upper = word1.toUpperCase()
    }
    var dict: Map[String, Array[String]] = Map().withDefaultValue(Array("DNE"))
    val filename = "data/cmudict-0.7b"
    val file: BufferedSource = Source.fromFile(filename)
    for (line <- file.getLines()) {
      if (line(0) != ';') {
        var key1 = line.split("  ")(0)
        var value1 = line.split(" ")
        dict += (key1 -> value1)
      }
    }
    return dict
  }

  def allRhymes2(word1: String): List[String] = {
    val Upper1 = word1.toUpperCase()
    val dict1 = alldict
    val word1sound = dict1(Upper1)
    val AllRhyme: ListBuffer[String] = ListBuffer()
    for (rhyme <- dict1.keys){
      val word2sound = dict1(rhyme)
      if (word2sound.length < word1sound.length){
        val result = processrhymes(word2sound, word1sound)
        if (result == true){
          AllRhyme += rhyme
        }
      }else{
        val result = processrhymes(word1sound, word2sound)
        if (result == true){
          AllRhyme += rhyme
        }
      }
    }
    AllRhyme -= Upper1
    val newlist = AllRhyme.toList
    println(newlist)
    newlist
  }

  def rhymeLength2(word1: String,word2: String): Int = {
    val Upper1 = word1.toUpperCase()
    val Upper2 = word2.toUpperCase()
    val dict = alldict
    var string1sound = dict(Upper1)
    var string2sound = dict(Upper2)
    val Rhyme = isRhyme(word1,word2)
    if (Rhyme == true){
      if (string1sound.length < string2sound.length){
        rhymeLengthhelper(string1sound, string2sound)
      }else{
        rhymeLengthhelper(string2sound, string1sound)
      }
    }else{
      return 0
    }
  }

  def bestRhyme(word: String): String = {
    var longest: Int = 0
    var longestword: String = ""
    var dict1: Map[String, Int] = Map()
    val nothin: String = ""
    alldict = wordexist(word)
    val wordsound = alldict(word.toUpperCase())
    if (wordsound != "DNE"){
      val allRhyme = allRhymes2(word)
      for (rhyme <- allRhyme){
        var rhymestring = rhyme.toString
        val length = rhymeLength2(rhymestring, word)
        dict1 += (rhymestring -> length)
      }
      for (key <- dict1.keys){
        val value = dict1(key)
        if (longest < value){
          longest = value
          longestword = key.toString
        }
      }
      longestword
    }else{
      nothin
    }
    longestword
  }
}
